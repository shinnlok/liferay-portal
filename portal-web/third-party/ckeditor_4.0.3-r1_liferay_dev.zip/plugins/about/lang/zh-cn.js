﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'about', 'zh-cn', {
	copy: 'Copyright &copy; $1. 版权所有。',
	dlgTitle: '关于CKEditor',
	help: '请访问 $1 以获取帮助.',
	moreInfo: '访问我们的网站以获取更多关于协议的信息',
	title: '关于CKEditor',
	userGuide: 'CKEditor 用户向导'
});
