﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'about', 'ca', {
	copy: 'Copyright &copy; $1. Tots els drets reservats.',
	dlgTitle: 'Quant al CKEditor',
	help: 'Premeu $1 per obtenir ajuda.',
	moreInfo: 'Per informació sobre llicències visiteu el web:',
	title: 'Quant al CKEditor',
	userGuide: 'Manual d\'usuari de CKEditor'
});
