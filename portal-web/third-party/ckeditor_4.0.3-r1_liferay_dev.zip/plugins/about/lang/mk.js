﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'about', 'mk', {
	copy: 'Copyright &copy; $1. All rights reserved.', // MISSING
	dlgTitle: 'About CKEditor', // MISSING
	help: 'Check $1 for help.', // MISSING
	moreInfo: 'For licensing information please visit our web site:', // MISSING
	title: 'About CKEditor', // MISSING
	userGuide: 'CKEditor User\'s Guide' // MISSING
});
