﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'basicstyles', 'sr', {
	bold: 'Подебљано',
	italic: 'Курзив',
	strike: 'Прецртано',
	subscript: 'Индекс',
	superscript: 'Степен',
	underline: 'Подвучено'
});
