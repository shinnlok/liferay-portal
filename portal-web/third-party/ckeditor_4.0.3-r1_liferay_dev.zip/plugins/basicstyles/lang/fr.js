﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'basicstyles', 'fr', {
	bold: 'Gras',
	italic: 'Italique',
	strike: 'Barré',
	subscript: 'Indice',
	superscript: 'Exposant',
	underline: 'Souligné'
});
