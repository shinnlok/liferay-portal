﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'basicstyles', 'ru', {
	bold: 'Полужирный',
	italic: 'Курсив',
	strike: 'Зачеркнутый',
	subscript: 'Подстрочный индекс',
	superscript: 'Надстрочный индекс',
	underline: 'Подчеркнутый'
});
