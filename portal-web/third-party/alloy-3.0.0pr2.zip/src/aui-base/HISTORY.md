# AUI Base

> Documentation and test modifications are not included in this changelog. For more details, see [full commit history](https://github.com/liferay/alloy-ui/commits/master/src/aui-base).

## @VERSION@

No registries yet.

## [3.0.0pr2](https://github.com/liferay/alloy-ui/releases/tag/3.0.0pr2)

* [AUI-1551](https://issues.liferay.com/browse/AUI-1551) Create unit test for camelize

## [2.5.0](https://github.com/liferay/alloy-ui/releases/tag/2.5.0)

* [AUI-1163](https://issues.liferay.com/browse/AUI-1163) Remove unnecessary constants